<header class="blog-post-page-title">
    <h4><?php the_title(); ?></h4>
</header>
<div class="blog-main-post blog-post-page-box">
    <article class="blog-post-block blog-post-page-content">
        <section>
            <?php the_content(); ?>
        </section>
        <footer class="blog-post-page-tags">

        </footer>
    </article>
</div>
