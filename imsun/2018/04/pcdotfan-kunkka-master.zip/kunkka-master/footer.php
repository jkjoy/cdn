</div>
</div>
<!-- #content -->
<div id="footer">
	<div class="container">
		<p>&copy; 2016 <a href="/"><?php bloginfo( 'name' ); ?></a> All Rights Reserved. <a href="http://mufeng.me/">Kunkka
				theme</a> powered by <a href="http://wordpress.org/">WordPress</a>.</p>
	</div>
</div>
<!-- #footer -->
<?php wp_footer(); ?>
</body>
</html>