<?php get_header(); ?>
<div id="primary">
	<div id="postlist">
		<p>页面出错或者没有此页面</p>
		<p>你也可以试着通过上方的搜索找到你想要看到的文章！</p>
	</div>
</div>
<?php get_sidebar();?>
<?php get_footer(); ?>	