<?php
/*
	框架 - 修复Lang支持库 重定义 NOW_LANG 常量的问题
	修复 - 登录时 偶尔跳出 已经登录XXX的提示
	修复 - 不使用大分组时 全部板块页面 不显示分类的问题
	优化 - 退出账号时不再提示退出成功 并且自动返回上一次浏览器的地方

	
	


	ZIP库

	图片压缩

	图片水印

*/
if(version_compare(PHP_VERSION,'5.3.0','<'))die('You Need PHP Version > 5.3.0 !  You PHP Version = ' . PHP_VERSION);

define('HYBBS_V'			,'1.5.18');
define('INDEX_PATH' 		, str_replace('\\', '/', dirname(__FILE__)).'/');
define('DEBUG'      		,(is_file(INDEX_PATH . 'DEBUG'))?false:true);
define('PLUGIN_ON'  		,true);
define('PLUGIN_ON_FILE'		,true);
define('PLUGIN_MORE_LANG_ON',true);

require INDEX_PATH . 'HY/HY.php';