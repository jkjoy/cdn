<?php
return array(
    'name' => 'Simditor编辑器',
    'user' => 'krabs',
    'icon' => 'edit',
    'mess' => '具体拥有的功能可以百度搜索一下Simditor编辑器,此款编辑器特点: 支持扩展, 多选图片同时上传, 表情, 以及常用的编辑器功能, 移动端表现良好,内置HOOK点',
    'version' => '1.25'
);
