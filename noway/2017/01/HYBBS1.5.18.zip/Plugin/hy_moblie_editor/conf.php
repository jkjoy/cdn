<?php
return array(
    'name' => 'HY移动编辑器',
    'user' => 'krabs',
    'icon' => '',
    'mess' => '手机移动设备编辑器',
    'version' => '1.13',
);