<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HYPHP</title>
  </head>
  <body>
    <div style="
    background: rgba(194, 194, 194, 0.45);
    padding: 10px;
    border-radius: 8px;
    font: 18px/1.6 Microsoft YaHei, Helvetica, sans-serif;
"><?php echo $text; ?></div>
  </body>
</html>