<?php


return array(
	'name'=>'官方后台模板',
	'mess'=>'官方后台模板',
	'user'=>'krabs',
	);